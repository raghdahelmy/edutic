<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('courses', function (Blueprint $table) {
        $table->enum('type', ['online', 'offline'])->default('online')->after('short_video');
        $table->decimal('price', 8, 2)->default(0)->after('type');
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('courses', function (Blueprint $table) {
        $table->dropColumn(['type', 'price']);
    });
    }
};
